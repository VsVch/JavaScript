import { html } from "../../node_modules/lit-html/lit-html.js";
import { editAlbumById, getAlbumById } from "../api/data.js";

const editTamplate = (album, onSubmit) => html`

<!-- Edit Page (Only for logged-in users) -->
      <section id="edit">
        <div class="form">
          <h2>Edit Album</h2>
          <form class="edit-form"  @submit=${onSubmit}>
            <input type="text" name="singer" id="album-singer" placeholder="Singer/Band" value="${album.singer}"/>
            <input type="text" name="album" id="album-album" placeholder="Album" value="${album.album}"/>
            <input type="text" name="imageUrl" id="album-img" placeholder="Image url" value="${album.imageUrl}"/>
            <input type="text" name="release" id="album-release" placeholder="Release date" value="${album.release}"/>
            <input type="text" name="label" id="album-label" placeholder="Label" value="${album.label}"/>
            <input type="text" name="sales" id="album-sales" placeholder="Sales" value="${album.sales}"/>

            <button type="submit">post</button>
          </form>
        </div>
      </section>




`;

export async function editPage(ctx) {
  const albumId = ctx.params.id;

  const album = await getAlbumById(AlbumId);
  ctx.render(editTamplate(album, onSubmit));

  async function onSubmit(event) {
    event.preventDefault();
    const formData = new FormData(event.target);

    const editAlbum = {
      title: formData.get("title").trim(),
      imageUrl: formData.get("imageUrl").trim(),
      category: formData.get("category").trim(),
      description: formData.get("description").trim(),
      requirements: formData.get("requirements").trim(),
      salary: formData.get("salary").trim(),
    };

    if (Object.values(editAlbum).some((x) => !x)) {
      return alert("All fields are required!");
    }

    await editAlbumById(albumId, editAlbum);
    event.target.reset();
    ctx.page.redirect(`/details/${albumId}`);
  }
}
