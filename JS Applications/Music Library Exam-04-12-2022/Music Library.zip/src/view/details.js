import { html } from "../../node_modules/lit-html/lit-html.js";
import {
  deleteAlbumById,
  getAlbumById,
  getTotalApplications,
  didUserApplied,
  apply,
} from "../api/data.js";

const detailsTamplate = (
  album,
  isOwner,
  onDelete,
  isLoggedIn,
  totalApplicationsCount,
  onClickApplication,
  didUserApply
) => html`<section id="details">
  <div id="details-wrapper">
    <img src="${offer.imageUrl}" alt="example1" />
    <p id="details-title">${offer.title}</p>
    <p id="details-category">
      Category: <span id="categories">${offer.category}</span>
    </p>
    <p id="details-salary">
      Salary: <span id="salary-number">${offer.salary}</span>
    </p>
    <div id="info-wrapper">
      <div id="details-description">
        <h4>Description</h4>
        <span>${offer.description}</span>
      </div>
      <div id="details-requirements">
        <h4>Requirements</h4>
        <span>${offer.requirements}</span>
      </div>
    </div>
    <p>
      Applications: <strong id="applications">${totalApplicationsCount}</strong>
    </p>
    <div id="action-buttons">
      ${isOwner
        ? html`<a href="/edit/${offer._id}" id="edit-btn">Edit</a>
            <a href="javascript:void(0)" id="delete-btn" @click=${onDelete}
              >Delete</a
            >`
        : ""}
      ${(() => {
        if (didUserApply == 0) {
          if (isLoggedIn && !isOwner) {
            return html`<a
              href="javascript:void(0)"
              @click=${onClickApplication}
              id="apply-btn"
              >Apply</a
            >`;
          }
        }
      })()}
    </div>
  </div>
</section>


<!-- Details page -->
<section id="details">
  <div id="details-wrapper">
    <p id="details-title">Album Details</p>
    <div id="img-wrapper">
      <img src="${album.imageUrl}" alt="example1" />
      
    </div>
    <div id="info-wrapper">
      <p><strong>Band:</strong><span id="details-singer">${album.singer}</span></p>
      <p><strong>Album name:</strong><span id="details-album">${album.album}</span></p>
      <p><strong>Release date:</strong><span id="details-release">${album.release}</span></p>
      <p><strong>Label:</strong><span id="details-label">${album.label}</span></p>
      <p><strong>Sales:</strong><span id="details-sales">${album.sales} (50 million claimed)</span></p>
    </div>
    <div id="likes">Likes: <span id="likes-count">0</span></div>

    <!--Edit and Delete are only for creator-->
    <div id="action-buttons">
    ${isOwner
      ? html`
      <a href="/edit/${album._id}" id="edit-btn">Edit</a>
      <a href="javascript:void(0)" id="delete-btn" @click=${onDelete}>Delete</a>
      `: ""}
      ${(() => {
        if (didUserApply == 0) {
          if (isLoggedIn && !isOwner) {
            return html`<a
              href="javascript:void(0)"
              @click=${onClickApplication}
              id="apply-btn"
              >Apply</a
            >`;
          }
        }
      })()}

    
    </div>
  </div>
</section>



`;

export async function detailsPage(ctx) {
  const albumId = ctx.params.id;
  const album = await getAlbumById(albumId);
  const user = ctx.user;

  let userId;
  let totalApplicationsCount;
  let didUserApply;

  if (user != null) {
    userId = user._id;
    didUserApply = await didUserApplied(albumId, userId);
  }

  const isOwner = user && album._ownerId == user._id;
  const isLoggedIn = user !== undefined;

  totalApplicationsCount = await getTotalApplications(albumId);
  ctx.render(
    detailsTamplate(
      album,
      isOwner,
      onDelete,
      isLoggedIn,
      totalApplicationsCount,
      onClickApplication,
      didUserApply
    )
  );

  async function onClickApplication() {
    const donation = {
      albumId,
    };
    await apply(donation);

    totalApplicationsCount = await getTotalApplications(albumId);
    didUserApply = await didUserApplied(albumId, userId);
    ctx.render(
      detailsTamplate(
        album,
        isOwner,
        onDelete,
        isLoggedIn,
        totalApplicationsCount,
        onClickApplication,
        didUserApplied
      )
    );
  }

  async function onDelete() {
    const confirmed = confirm("Are you sure?");
    if (confirmed) {
      await deleteAlbumById(albumId);
      ctx.page.redirect("/");
    }
  }
}
